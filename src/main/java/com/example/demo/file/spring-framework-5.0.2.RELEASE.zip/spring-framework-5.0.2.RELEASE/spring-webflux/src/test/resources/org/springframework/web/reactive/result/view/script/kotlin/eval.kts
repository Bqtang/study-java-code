// TODO Improve syntax when KT-15125 will be fixed
"""${bindings["header"]}
<p>${bindings["hello"]} ${bindings["foo"]}</p>
${bindings["footer"]}"""
